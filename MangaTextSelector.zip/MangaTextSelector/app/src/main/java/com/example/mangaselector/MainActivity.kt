package com.example.mangaselector

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import android.graphics.Rect

class MainActivity : AppCompatActivity() {

    private lateinit var mangaImage: ImageView
    private lateinit var overlay: SelectionOverlayView
    private lateinit var emptyCanvasHint: TextView
    private lateinit var statusMessage: TextView
    private lateinit var selectedText: TextView
    private lateinit var btnDetect: Button
    private lateinit var btnSquare: Button
    private lateinit var btnOval: Button
    private lateinit var btnCircle: Button

    private var bitmap: Bitmap? = null
    private var chosenRegion: TextRegion? = null
    private var selectedShape = SelectionOverlayView.Shape.RECTANGLE

    private lateinit var latinRecognizer: TextRecognizer
    private lateinit var japaneseRecognizer: TextRecognizer

    private val imagePicker = registerForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) loadImage(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mangaImage = findViewById(R.id.mangaImage)
        overlay = findViewById(R.id.selectionOverlay)
        emptyCanvasHint = findViewById(R.id.emptyCanvasHint)
        statusMessage = findViewById(R.id.statusMessage)
        selectedText = findViewById(R.id.selectedText)
        btnDetect = findViewById(R.id.btnDetect)
        btnSquare = findViewById(R.id.btnSquare)
        btnOval = findViewById(R.id.btnOval)
        btnCircle = findViewById(R.id.btnCircle)

        latinRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        japaneseRecognizer = TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())

        findViewById<Button>(R.id.btnUpload).setOnClickListener {
            imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
        btnDetect.setOnClickListener { detectText() }
        btnSquare.setOnClickListener { chooseShape(SelectionOverlayView.Shape.RECTANGLE) }
        btnOval.setOnClickListener { chooseShape(SelectionOverlayView.Shape.OVAL) }
        btnCircle.setOnClickListener { chooseShape(SelectionOverlayView.Shape.CIRCLE) }
        findViewById<Button>(R.id.btnCopy).setOnClickListener { copySelectedText() }

        overlay.onRegionTapped = { region ->
            chosenRegion = region
            selectedText.text = "Teks terpilih: ${region.text.trim().ifBlank { "(teks tidak terbaca)" }}"
            statusMessage.text = "Status: blok teks dipilih. Pilih bentuk lain atau sentuh blok lainnya."
        }

        chooseShape(selectedShape)
    }

    private fun loadImage(uri: Uri) {
        statusMessage.text = "Status: membaca gambar..."
        try {
            val decoded = decodeBitmapSafely(uri)
            if (decoded == null) {
                statusMessage.text = "Status: gambar tidak dapat dibuka. Coba file lain."
                return
            }
            bitmap = decoded
            mangaImage.setImageBitmap(decoded)
            overlay.setImageSize(decoded.width, decoded.height)
            overlay.setRegions(emptyList())
            overlay.clearSelection()
            emptyCanvasHint.visibility = android.view.View.GONE
            chosenRegion = null
            selectedText.text = "Teks terpilih: belum ada"
            statusMessage.text = "Status: gambar siap (${decoded.width} × ${decoded.height}). Tekan Deteksi Teks."
            btnDetect.isEnabled = true
        } catch (e: Exception) {
            statusMessage.text = "Status: gagal membaca gambar (${e.localizedMessage ?: "kesalahan file"})."
        }
    }

    /** Limits decoded image memory while retaining as much detail as practical for OCR. */
    private fun decodeBitmapSafely(uri: Uri): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sample = 1
        while ((bounds.outWidth / sample > 6000 || bounds.outHeight / sample > 6000 ||
                    (bounds.outWidth.toLong() / sample) * (bounds.outHeight.toLong() / sample) > 24_000_000L) && sample < 32) {
            sample *= 2
        }
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        return contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
    }

    private fun detectText() {
        val currentBitmap = bitmap
        if (currentBitmap == null) {
            statusMessage.text = "Status: pilih gambar terlebih dahulu."
            return
        }

        btnDetect.isEnabled = false
        statusMessage.text = "Status: OCR berjalan (Latin + Jepang)..."
        selectedText.text = "Teks terpilih: —"
        chosenRegion = null
        overlay.clearSelection()

        val input = try {
            InputImage.fromBitmap(currentBitmap, 0)
        } catch (e: Exception) {
            btnDetect.isEnabled = true
            statusMessage.text = "Status: gambar tidak bisa diproses."
            return
        }

        val latinTask = latinRecognizer.process(input)
        val japaneseTask = japaneseRecognizer.process(input)

        Tasks.whenAllComplete(latinTask, japaneseTask)
            .addOnSuccessListener { tasks ->
                val detections = mutableListOf<TextRegion>()
                if (latinTask.isSuccessful) detections.addAll(regionsFrom(latinTask.result))
                if (japaneseTask.isSuccessful) detections.addAll(regionsFrom(japaneseTask.result))

                val finalRegions = deduplicateRegions(detections)
                overlay.setRegions(finalRegions)
                btnDetect.isEnabled = true

                if (finalRegions.isEmpty()) {
                    statusMessage.text = "Status: teks belum terdeteksi. Coba gambar yang lebih tajam atau kontras."
                } else {
                    statusMessage.text = "Status: ${finalRegions.size} blok terdeteksi. Sentuh kotak hijau pada teks yang ingin dipilih."
                }
                // Touching a detected region is still useful when one recognizer failed.
                if (tasks.none { it.isSuccessful }) {
                    statusMessage.text = "Status: OCR gagal pada kedua model. Coba gambar lain."
                }
            }
            .addOnFailureListener { error ->
                btnDetect.isEnabled = true
                statusMessage.text = "Status: OCR gagal (${error.localizedMessage ?: "kesalahan tidak diketahui"})."
            }
    }

    private fun regionsFrom(result: Text?): List<TextRegion> {
        if (result == null) return emptyList()
        return result.textBlocks.mapNotNull { block ->
            val box = block.boundingBox ?: return@mapNotNull null
            if (box.width() <= 0 || box.height() <= 0) return@mapNotNull null
            TextRegion(Rect(box), block.text)
        }
    }

    /** Remove same-region boxes returned by both script recognizers. */
    private fun deduplicateRegions(input: List<TextRegion>): List<TextRegion> {
        val kept = mutableListOf<TextRegion>()
        input.sortedByDescending { it.bounds.width().toLong() * it.bounds.height().toLong() }
            .forEach { candidate ->
                val duplicateIndex = kept.indexOfFirst { existing ->
                    val intersection = Rect(existing.bounds)
                    if (!intersection.intersect(candidate.bounds)) {
                        false
                    } else {
                        val intersectionArea = intersection.width().toLong() * intersection.height().toLong()
                        val candidateArea = candidate.bounds.width().toLong() * candidate.bounds.height().toLong()
                        val existingArea = existing.bounds.width().toLong() * existing.bounds.height().toLong()
                        val smallerArea = minOf(candidateArea, existingArea).coerceAtLeast(1L)
                        intersectionArea.toDouble() / smallerArea.toDouble() >= 0.72
                    }
                }
                if (duplicateIndex < 0) {
                    kept.add(candidate)
                } else if (candidate.text.length > kept[duplicateIndex].text.length) {
                    kept[duplicateIndex] = candidate
                }
            }
        return kept.sortedWith(compareBy<TextRegion> { it.bounds.top }.thenBy { it.bounds.left })
    }

    private fun chooseShape(shape: SelectionOverlayView.Shape) {
        selectedShape = shape
        overlay.setShape(shape)
        val active = ColorStateList.valueOf(Color.rgb(36, 107, 253))
        val inactive = ColorStateList.valueOf(Color.rgb(230, 235, 244))
        val activeText = Color.WHITE
        val inactiveText = Color.rgb(34, 45, 66)

        listOf(
            btnSquare to (shape == SelectionOverlayView.Shape.RECTANGLE),
            btnOval to (shape == SelectionOverlayView.Shape.OVAL),
            btnCircle to (shape == SelectionOverlayView.Shape.CIRCLE)
        ).forEach { (button, isActive) ->
            button.backgroundTintList = if (isActive) active else inactive
            button.setTextColor(if (isActive) activeText else inactiveText)
        }
        val selected = chosenRegion
        if (selected != null) {
            statusMessage.text = "Status: bentuk seleksi diubah. Teks tetap: ${selected.text.trim().take(70)}"
        }
    }

    private fun copySelectedText() {
        val text = chosenRegion?.text?.trim().orEmpty()
        if (text.isBlank()) {
            Toast.makeText(this, "Pilih blok teks terlebih dahulu.", Toast.LENGTH_SHORT).show()
            return
        }
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Teks manga", text))
        Toast.makeText(this, "Teks disalin ke clipboard.", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        if (::latinRecognizer.isInitialized) latinRecognizer.close()
        if (::japaneseRecognizer.isInitialized) japaneseRecognizer.close()
        super.onDestroy()
    }
}
