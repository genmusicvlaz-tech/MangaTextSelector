package com.example.mangaselector

import android.graphics.Rect

/** Bounding box and OCR text for one recognized text block, in bitmap coordinates. */
data class TextRegion(
    val bounds: Rect,
    val text: String
)
