package com.example.mangaselector

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Draws OCR regions over a FIT_CENTER image and lets the user tap a text region. */
class SelectionOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    enum class Shape { RECTANGLE, OVAL, CIRCLE }

    private var imageWidth = 0
    private var imageHeight = 0
    private var regions: List<TextRegion> = emptyList()
    private var selected: TextRegion? = null
    private var currentShape = Shape.RECTANGLE

    var onRegionTapped: ((TextRegion) -> Unit)? = null

    private val detectedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(185, 67, 214, 180)
        style = Paint.Style.STROKE
        strokeWidth = dp(1.2f)
    }
    private val selectedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 174, 66)
        style = Paint.Style.STROKE
        strokeWidth = dp(2.8f)
    }
    private val selectedFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(34, 255, 174, 66)
        style = Paint.Style.FILL
    }

    fun setImageSize(width: Int, height: Int) {
        imageWidth = width
        imageHeight = height
        invalidate()
    }

    fun setRegions(newRegions: List<TextRegion>) {
        regions = newRegions.map { TextRegion(Rect(it.bounds), it.text) }
        selected = null
        invalidate()
    }

    fun setShape(shape: Shape) {
        currentShape = shape
        invalidate()
    }

    fun clearSelection() {
        selected = null
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (imageWidth <= 0 || imageHeight <= 0) return

        regions.forEach { region ->
            if (region != selected) {
                mapRect(region.bounds)?.let { canvas.drawRect(it, detectedPaint) }
            }
        }

        selected?.let { region ->
            val rect = mapRect(region.bounds) ?: return@let
            when (currentShape) {
                Shape.RECTANGLE -> {
                    canvas.drawRect(rect, selectedFillPaint)
                    canvas.drawRect(rect, selectedPaint)
                }
                Shape.OVAL -> {
                    canvas.drawOval(rect, selectedFillPaint)
                    canvas.drawOval(rect, selectedPaint)
                }
                Shape.CIRCLE -> {
                    val radius = max(rect.width(), rect.height()) / 2f
                    canvas.drawCircle(rect.centerX(), rect.centerY(), radius, selectedFillPaint)
                    canvas.drawCircle(rect.centerX(), rect.centerY(), radius, selectedPaint)
                }
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action != MotionEvent.ACTION_UP) return true
        val displayRect = imageDisplayRect() ?: return true
        if (!displayRect.contains(event.x, event.y)) return true

        val scale = min(displayRect.width() / imageWidth.toFloat(), displayRect.height() / imageHeight.toFloat())
        if (scale <= 0f) return true
        val x = ((event.x - displayRect.left) / scale).toInt()
        val y = ((event.y - displayRect.top) / scale).toInt()

        val hit = regions.firstOrNull { it.bounds.contains(x, y) } ?: findNearestRegion(x, y, 42f / scale)
        if (hit != null) {
            selected = hit
            invalidate()
            onRegionTapped?.invoke(hit)
        }
        performClick()
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun findNearestRegion(x: Int, y: Int, radius: Float): TextRegion? {
        var best: TextRegion? = null
        var bestDistance = Float.MAX_VALUE
        regions.forEach { region ->
            val r = region.bounds
            val dx = when {
                x < r.left -> (r.left - x).toFloat()
                x > r.right -> (x - r.right).toFloat()
                else -> 0f
            }
            val dy = when {
                y < r.top -> (r.top - y).toFloat()
                y > r.bottom -> (y - r.bottom).toFloat()
                else -> 0f
            }
            val distance = sqrt(dx * dx + dy * dy)
            if (distance < bestDistance) {
                bestDistance = distance
                best = region
            }
        }
        return if (bestDistance <= radius) best else null
    }

    private fun imageDisplayRect(): RectF? {
        if (imageWidth <= 0 || imageHeight <= 0 || width <= 0 || height <= 0) return null
        val scale = min(width.toFloat() / imageWidth, height.toFloat() / imageHeight)
        val drawnWidth = imageWidth * scale
        val drawnHeight = imageHeight * scale
        val left = (width - drawnWidth) / 2f
        val top = (height - drawnHeight) / 2f
        return RectF(left, top, left + drawnWidth, top + drawnHeight)
    }

    private fun mapRect(rect: Rect): RectF? {
        val destination = imageDisplayRect() ?: return null
        val scaleX = destination.width() / imageWidth.toFloat()
        val scaleY = destination.height() / imageHeight.toFloat()
        return RectF(
            destination.left + rect.left * scaleX,
            destination.top + rect.top * scaleY,
            destination.left + rect.right * scaleX,
            destination.top + rect.bottom * scaleY
        )
    }

    private fun dp(value: Float): Float = value * resources.displayMetrics.density
}
